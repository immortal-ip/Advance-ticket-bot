# Advanced Ticket Bot

Made by Akshay 🚀

## Commands:
- +ticket
- /ticketpanel
- /setlogchannel
- +help (Dropdown)
- Close button

## Setup:
1. Edit .env
2. Deploy commands
3. Run index.js

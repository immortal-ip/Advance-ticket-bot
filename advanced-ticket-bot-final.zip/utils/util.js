// Utility functions placeholder
